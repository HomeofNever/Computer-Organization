/* lab03-cp3.c */

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

int main()
{
  char line[128];
  char output[128];

  // Open up the text file
  FILE* file = fopen("book-1984.txt", "r");
  if (file == NULL) {
    perror("fopen() failed");
    return EXIT_FAILURE;
  }

  while (fgets(line, 128, file) != NULL) // while there's unread lines in file
  {
    // Initialize pointers to 'index 0' of the input and output buffers
    char* p = line;
    char* q = output;

    while (*p) // until we reach the end of 'line'
    {
      // If p's current pointed-to location in line contains an alpha-numeric 
      //  character, then copy it to the output buffer at location q, and then 
      //  increment both of their locations
      // Otherwise, just increment p
      if (isalnum(*p))
        *q++ = *p;
      ++p;
    }

    // Only output if the line contains alpha-numeric characters
    if (q > output) 
    {
      *q = '\0'; // NULL terminate!
      printf("%s [%lu alnum chars]\n", output, q-output);
    }
  }

  fclose(file);

  return EXIT_SUCCESS;
}

/*
$ ./a.out
PARTONE [7 alnum chars]
Chapter1 [8 alnum chars]
ItwasabrightcolddayinAprilandtheclockswerestrikingthirteen [58 alnum chars]
WinstonSmithhischinnuzzledintohisbreastinanefforttoescapethe [60 alnum chars]
vilewindslippedquicklythroughtheglassdoorsofVictoryMansions [59 alnum chars]
thoughnotquicklyenoughtopreventaswirlofgrittydustfromentering [61 alnum chars]
alongwithhim [12 alnum chars]
ThehallwaysmeltofboiledcabbageandoldragmatsAtoneendofita [56 alnum chars]
colouredpostertoolargeforindoordisplayhadbeentackedtothewall [60 alnum chars]
Itdepictedsimplyanenormousfacemorethanametrewidethefaceofa [58 alnum chars]
manofaboutfortyfivewithaheavyblackmoustacheandruggedlyhandsome [62 alnum chars]
featuresWinstonmadeforthestairsItwasnousetryingtheliftEven [58 alnum chars]
atthebestoftimesitwasseldomworkingandatpresenttheelectric [57 alnum chars]
currentwascutoffduringdaylighthoursItwaspartoftheeconomydrive [61 alnum chars]
inpreparationforHateWeekTheflatwassevenflightsupandWinston [58 alnum chars]
whowasthirtynineandhadavaricoseulcerabovehisrightanklewent [58 alnum chars]
slowlyrestingseveraltimesonthewayOneachlandingoppositethe [57 alnum chars]
liftshafttheposterwiththeenormousfacegazedfromthewallItwas [58 alnum chars]
oneofthosepictureswhicharesocontrivedthattheeyesfollowyouabout [62 alnum chars]
...
...
...
Agooddealoftheliteratureofthepastwasindeedalreadybeing [54 alnum chars]
transformedinthiswayConsiderationsofprestigemadeitdesirableto [61 alnum chars]
preservethememoryofcertainhistoricalfigureswhileatthesametime [61 alnum chars]
bringingtheirachievementsintolinewiththephilosophyofIngsoc [58 alnum chars]
VariouswriterssuchasShakespeareMiltonSwiftByronDickensand [57 alnum chars]
someotherswerethereforeinprocessoftranslationwhenthetaskhad [59 alnum chars]
beencompletedtheiroriginalwritingswithallelsethatsurvivedof [59 alnum chars]
theliteratureofthepastwouldbedestroyedThesetranslationswere [59 alnum chars]
aslowanddifficultbusinessanditwasnotexpectedthattheywould [57 alnum chars]
befinishedbeforethefirstorseconddecadeofthetwentyfirst [54 alnum chars]
centuryTherewerealsolargequantitiesofmerelyutilitarian [54 alnum chars]
literatureindispensabletechnicalmanualsandthelikethathadto [58 alnum chars]
betreatedinthesamewayItwaschieflyinordertoallowtimefor [54 alnum chars]
thepreliminaryworkoftranslationthatthefinaladoptionofNewspeak [61 alnum chars]
hadbeenfixedforsolateadateas2050 [32 alnum chars]
THEEND [6 alnum chars]
*/
