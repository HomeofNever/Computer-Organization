/* lab03-cp1.c */

#include <stdio.h>
#include <stdlib.h>

int main()
{
  int data_file_bytes = 744; // From 'ls'

  // Assuming we're going to be reading 'int' types
  int num_data_points = 744 / sizeof(int);
  int* values = calloc(num_data_points, sizeof(int));
  
  FILE* file = fopen("lab03-data.dat", "r");  // man fopen 
  if (file == NULL) {
    perror("fopen() failed"); // use this if errno is set (see man page)
    return EXIT_FAILURE;
  }

  int values_read = fread(values, sizeof(int), num_data_points, file);
  if (values_read != num_data_points)
  {
    fprintf(stderr, "ERROR: fread() failed\n" );
    return EXIT_FAILURE;
  }

  fclose(file);

  for (int i = 0 ; i < num_data_points ; ++i) {
    printf( "Data point #%3d: %d\n", i, values[i] );
  }

  free(values);

  return EXIT_SUCCESS;
}

/*
$ ./a.out
Data point #  0: 0
Data point #  1: 0
Data point #  2: 1
Data point #  3: 0
Data point #  4: 1
Data point #  5: 0
Data point #  6: 2
Data point #  7: 0
Data point #  8: 3
Data point #  9: 0
Data point # 10: 5
Data point # 11: 0
Data point # 12: 8
Data point # 13: 0
Data point # 14: 13
Data point # 15: 0
Data point # 16: 21
Data point # 17: 0
Data point # 18: 34
Data point # 19: 0
Data point # 20: 55
Data point # 21: 0
Data point # 22: 89
Data point # 23: 0
Data point # 24: 144
Data point # 25: 0
Data point # 26: 233
Data point # 27: 0
Data point # 28: 377
Data point # 29: 0
Data point # 30: 610
Data point # 31: 0
Data point # 32: 987
Data point # 33: 0
Data point # 34: 1597
Data point # 35: 0
Data point # 36: 2584
Data point # 37: 0
Data point # 38: 4181
Data point # 39: 0
Data point # 40: 6765
Data point # 41: 0
Data point # 42: 10946
Data point # 43: 0
Data point # 44: 17711
Data point # 45: 0
Data point # 46: 28657
Data point # 47: 0
Data point # 48: 46368
Data point # 49: 0
Data point # 50: 75025
Data point # 51: 0
Data point # 52: 121393
Data point # 53: 0
Data point # 54: 196418
Data point # 55: 0
Data point # 56: 317811
Data point # 57: 0
Data point # 58: 514229
Data point # 59: 0
Data point # 60: 832040
Data point # 61: 0
Data point # 62: 1346269
Data point # 63: 0
Data point # 64: 2178309
Data point # 65: 0
Data point # 66: 3524578
Data point # 67: 0
Data point # 68: 5702887
Data point # 69: 0
Data point # 70: 9227465
Data point # 71: 0
Data point # 72: 14930352
Data point # 73: 0
Data point # 74: 24157817
Data point # 75: 0
Data point # 76: 39088169
Data point # 77: 0
Data point # 78: 63245986
Data point # 79: 0
Data point # 80: 102334155
Data point # 81: 0
Data point # 82: 165580141
Data point # 83: 0
Data point # 84: 267914296
Data point # 85: 0
Data point # 86: 433494437
Data point # 87: 0
Data point # 88: 701408733
Data point # 89: 0
Data point # 90: 1134903170
Data point # 91: 0
Data point # 92: 1836311903
Data point # 93: 0
Data point # 94: -1323752223
Data point # 95: 0
Data point # 96: 512559680
Data point # 97: 1
Data point # 98: -811192543
Data point # 99: 1
Data point #100: -298632863
Data point #101: 2
Data point #102: -1109825406
Data point #103: 4
Data point #104: -1408458269
Data point #105: 7
Data point #106: 1776683621
Data point #107: 12
Data point #108: 368225352
Data point #109: 20
Data point #110: 2144908973
Data point #111: 32
Data point #112: -1781832971
Data point #113: 52
Data point #114: 363076002
Data point #115: 85
Data point #116: -1418756969
Data point #117: 137
Data point #118: -1055680967
Data point #119: 222
Data point #120: 1820529360
Data point #121: 360
Data point #122: 764848393
Data point #123: 583
Data point #124: -1709589543
Data point #125: 943
Data point #126: -944741150
Data point #127: 1526
Data point #128: 1640636603
Data point #129: 2470
Data point #130: 695895453
Data point #131: 3997
Data point #132: -1958435240
Data point #133: 6467
Data point #134: -1262539787
Data point #135: 10464
Data point #136: 1073992269
Data point #137: 16932
Data point #138: -188547518
Data point #139: 27396
Data point #140: 885444751
Data point #141: 44329
Data point #142: 696897233
Data point #143: 71726
Data point #144: 1582341984
Data point #145: 116055
Data point #146: -2015728079
Data point #147: 187781
Data point #148: -433386095
Data point #149: 303836
Data point #150: 1845853122
Data point #151: 491618
Data point #152: 1412467027
Data point #153: 795455
Data point #154: -1036647147
Data point #155: 1287073
Data point #156: 375819880
Data point #157: 2082529
Data point #158: -660827267
Data point #159: 3369602
Data point #160: -285007387
Data point #161: 5452131
Data point #162: -945834654
Data point #163: 8821734
Data point #164: -1230842041
Data point #165: 14273866
Data point #166: 2118290601
Data point #167: 23095601
Data point #168: 887448560
Data point #169: 37369468
Data point #170: -1289228135
Data point #171: 60465069
Data point #172: -401779575
Data point #173: 97834537
Data point #174: -1691007710
Data point #175: 158299607
Data point #176: -2092787285
Data point #177: 256134145
Data point #178: 511172301
Data point #179: 414433753
Data point #180: -1581614984
Data point #181: 670567898
Data point #182: -1070442683
Data point #183: 1085001651
Data point #184: 1642909629
Data point #185: 1755569550
*/