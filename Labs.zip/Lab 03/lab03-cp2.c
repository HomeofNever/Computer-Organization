/* lab03-cp2.c */

#include <stdio.h>
#include <stdlib.h>

int main()
{
  int data_file_bytes = 744; // From 'ls'

  // Use 'unsigned long' instead of 'int'
  int num_data_points = 744 / sizeof(unsigned long); 
  unsigned long* values = calloc(num_data_points, sizeof(unsigned long));
  
  FILE* file = fopen("lab03-data.dat", "r");  // man fopen 
  if (file == NULL) {
    perror("fopen() failed"); // use this if errno is set (see man page)
    return EXIT_FAILURE;
  }

  int values_read = fread(values, sizeof(unsigned long), num_data_points, file);
  if (values_read != num_data_points)
  {
    fprintf(stderr, "ERROR: fread() failed\n" );
    return EXIT_FAILURE;
  }

  fclose(file);

  for (int i = 0 ; i < num_data_points ; ++i) {
    printf( "Data point #%3d: %li\n", i, values[i] );
  }

  free(values);

  return EXIT_SUCCESS;
}

/*
$ ./a.out
Data point #  0: 0
Data point #  1: 1
Data point #  2: 1
Data point #  3: 2
Data point #  4: 3
Data point #  5: 5
Data point #  6: 8
Data point #  7: 13
Data point #  8: 21
Data point #  9: 34
Data point # 10: 55
Data point # 11: 89
Data point # 12: 144
Data point # 13: 233
Data point # 14: 377
Data point # 15: 610
Data point # 16: 987
Data point # 17: 1597
Data point # 18: 2584
Data point # 19: 4181
Data point # 20: 6765
Data point # 21: 10946
Data point # 22: 17711
Data point # 23: 28657
Data point # 24: 46368
Data point # 25: 75025
Data point # 26: 121393
Data point # 27: 196418
Data point # 28: 317811
Data point # 29: 514229
Data point # 30: 832040
Data point # 31: 1346269
Data point # 32: 2178309
Data point # 33: 3524578
Data point # 34: 5702887
Data point # 35: 9227465
Data point # 36: 14930352
Data point # 37: 24157817
Data point # 38: 39088169
Data point # 39: 63245986
Data point # 40: 102334155
Data point # 41: 165580141
Data point # 42: 267914296
Data point # 43: 433494437
Data point # 44: 701408733
Data point # 45: 1134903170
Data point # 46: 1836311903
Data point # 47: 2971215073
Data point # 48: 4807526976
Data point # 49: 7778742049
Data point # 50: 12586269025
Data point # 51: 20365011074
Data point # 52: 32951280099
Data point # 53: 53316291173
Data point # 54: 86267571272
Data point # 55: 139583862445
Data point # 56: 225851433717
Data point # 57: 365435296162
Data point # 58: 591286729879
Data point # 59: 956722026041
Data point # 60: 1548008755920
Data point # 61: 2504730781961
Data point # 62: 4052739537881
Data point # 63: 6557470319842
Data point # 64: 10610209857723
Data point # 65: 17167680177565
Data point # 66: 27777890035288
Data point # 67: 44945570212853
Data point # 68: 72723460248141
Data point # 69: 117669030460994
Data point # 70: 190392490709135
Data point # 71: 308061521170129
Data point # 72: 498454011879264
Data point # 73: 806515533049393
Data point # 74: 1304969544928657
Data point # 75: 2111485077978050
Data point # 76: 3416454622906707
Data point # 77: 5527939700884757
Data point # 78: 8944394323791464
Data point # 79: 14472334024676221
Data point # 80: 23416728348467685
Data point # 81: 37889062373143906
Data point # 82: 61305790721611591
Data point # 83: 99194853094755497
Data point # 84: 160500643816367088
Data point # 85: 259695496911122585
Data point # 86: 420196140727489673
Data point # 87: 679891637638612258
Data point # 88: 1100087778366101931
Data point # 89: 1779979416004714189
Data point # 90: 2880067194370816120
Data point # 91: 4660046610375530309
Data point # 92: 7540113804746346429

Fibonacci makes another appearance! Wooo woo!
*/
