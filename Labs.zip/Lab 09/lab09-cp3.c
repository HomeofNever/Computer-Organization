/* lab09.c */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>


/* Perform a logical shift-left operation on bitbucket,
 * pushing the given bit input as the least-significant bit (lsb).
 *
 * Return the resulting 32-bit integer.
 */
uint32_t push_lsb_bit( uint32_t bitbucket, uint32_t bit )
{
	bitbucket <<= 1;
	bitbucket |= bit & 0x01;
    return bitbucket;
}


/* Perform a logical shift-right operation on bitbucket,
 * popping and returning the least-significant bit (lsb).
 *
 * Note that bitbucket is passed by reference and should
 * be changed accordingly.
 */
uint32_t pop_lsb_bit( uint32_t * bitbucket )
{
	uint32_t bit = *bitbucket & 0x01;
	*bitbucket >>= 1;
    return bit;
}


/* Print out a 32-bit binary string using pop_lsb_bit().
 */
void print_b32( uint32_t s )
{
    int i;
    uint32_t binaryString[32];
    
    for ( i = 0 ; i < 32 ; i++ )
    {
        binaryString[i] = pop_lsb_bit( &s );
    }
    
    for ( i = 31 ; i >= 0 ; i-- )
    {
        printf( "%d", binaryString[i] );
    }

    printf( "\n" );
}


/* Isolate a range of bits within a given 32-bit integer.
 * More specifically, return the integer containing bits
 * from input bitbucket starting at msbindex and ending at
 * lsbindex, where index ranges from 0 (lsb) to 31 (msb).
 *
 * e.g., if bitbucket is 123, msbindex is 5 and lsbindex is 1:
 *
 *       0000 0000 0000 0000 0000 0000 0111 1011
 *                                       ^    ^
 *                                 msbindex  lsbindex
 *
 *       0000 0000 0000 0000 0000 0000 0001 1101
 *
 *       function returns 16+8+4+1=29 in this example
 */
uint32_t isolate_bits( uint32_t bitbucket, uint32_t msbindex, uint32_t lsbindex )
{
	bitbucket = bitbucket << (31 - msbindex) >> (31 - msbindex + lsbindex);


    return bitbucket;
}


/* Decode the given instruction by:
 * (1) determining the instruction opcode
 * (2) based on the opcode, returning the appropriate
 *     funct code (or zero if not applicable)
 *
 * Display the decoded instruction opcode by printing
 * add, slt, sub, j, beq, etc. as follows:
 *
 *   INSTRUCTION OPCODE: add
 *
 * Also, when applicable, display the ALU control lines
 * (from Figure B.5.13) using the format shown below:
 *
 *   ALU CONTROL INPUT: 0010
 */
uint32_t decode_inst( uint32_t instruction )
{
	uint32_t opcode = isolate_bits(instruction, 31, 26);
	uint32_t funct_code = isolate_bits(instruction, 5, 0);
	uint32_t ALUOp, Operation0, Operation1, Operation2, Operation3 = 0;
	char* opcode_str;
	if (opcode == 0x00) {
		if (funct_code == 0x00) opcode_str = "sll";
		else if (funct_code == 0x02) opcode_str = "srl";
		else if (funct_code == 0x03) opcode_str = "sra";
		else if (funct_code == 0x08) opcode_str = "jr";
		else if (funct_code == 0x10) opcode_str = "mfhi";
		else if (funct_code == 0x11) opcode_str = "mthi";
		else if (funct_code == 0x12) opcode_str = "mflo";
		else if (funct_code == 0x13) opcode_str = "mtlo";
		else if (funct_code == 0x18) opcode_str = "mult";
		else if (funct_code == 0x19) opcode_str = "multu";
		else if (funct_code == 0x1A) opcode_str = "div";
		else if (funct_code == 0x1B) opcode_str = "divu";
		else if (funct_code == 0x20) opcode_str = "add";
		else if (funct_code == 0x21) opcode_str = "addu";
		else if (funct_code == 0x22) opcode_str = "sub";
		else if (funct_code == 0x23) opcode_str = "subu";
		else if (funct_code == 0x24) opcode_str = "and";
		else if (funct_code == 0x25) opcode_str = "or";
		else if (funct_code == 0x26) opcode_str = "xor";
		else if (funct_code == 0x27) opcode_str = "nor";
		else if (funct_code == 0x2A) opcode_str = "slt";
		else if (funct_code == 0x2B) opcode_str = "sltu";
	}
	else {
		funct_code = 0x00;
		if (opcode == 0x02) opcode_str = "j";
		else if (opcode == 0x03) opcode_str = "jal";
		else if (opcode == 0x04) opcode_str = "beq";
		else if (opcode == 0x05) opcode_str = "bne";
		else if (opcode == 0x06) opcode_str = "blez";
		else if (opcode == 0x07) opcode_str = "bgtz";
		else if (opcode == 0x08) opcode_str = "addi";
		else if (opcode == 0x09) opcode_str = "addiu";
		else if (opcode == 0x0A) opcode_str = "slti";
		else if (opcode == 0x0B) opcode_str = "sltiu";
		else if (opcode == 0x0C) opcode_str = "andi";
		else if (opcode == 0x0D) opcode_str = "ori";
		else if (opcode == 0x0F) opcode_str = "lui";
		else if (opcode == 0x10) opcode_str = "mfc0";
		else if (opcode == 0x20) opcode_str = "lb";
		else if (opcode == 0x23) opcode_str = "lw";
		else if (opcode == 0x24) opcode_str = "lbu";
		else if (opcode == 0x25) opcode_str = "lhu";
		else if (opcode == 0x28) opcode_str = "sb";
		else if (opcode == 0x29) opcode_str = "sh";
		else if (opcode == 0x2B) opcode_str = "sw";
	}
	printf("INSTRUCTION OPCODE: %s\n", opcode_str);
	if (strcmp(opcode_str, "lw") == 0 || strcmp(opcode_str, "sw") == 0) ALUOp = 0x00;
	else if (strcmp(opcode_str, "beq") == 0) ALUOp = 0x01;
	else if (strcmp(opcode_str, "add") == 0 || strcmp(opcode_str, "sub") == 0 || 
		strcmp(opcode_str, "and") == 0 || strcmp(opcode_str, "or") == 0 || 
		strcmp(opcode_str, "slt") == 0) ALUOp = 0x02;
	else return funct_code;
	Operation0 = (isolate_bits(funct_code, 3, 3) || isolate_bits(funct_code, 0, 0)) 
		&& isolate_bits(ALUOp, 1, 1); // (F3 || F0) && ALUOp1
	Operation1 = isolate_bits(~ALUOp, 1, 1) || isolate_bits (~funct_code, 2, 2); // not(ALUOp1) || not(F2)
	Operation2 = (isolate_bits(funct_code, 1, 1) && isolate_bits(ALUOp, 1, 1))
		|| isolate_bits(ALUOp, 0, 0); // (F1 && ALUOp1) || ALUOp0
	printf("ALU CONTROL INPUT: %d%d%d%d\n", Operation3, Operation2, Operation1, Operation0);
    return funct_code;
}


/* Add other tests to main() */
int main()
{
    int i;

    /*********** CHECKPOINT 1 ***********/
    // Testing pop_lsb_bit( 13 ):
    // 00000000000000000000000000001101
    // push_lsb_bit( 13, 1 ) is 27
    // in binary:
    // 00000000000000000000000000011011

    printf( "Testing pop_lsb_bit( 13 ):\n" );
    uint32_t temp = 13;
    print_b32( temp );

    uint32_t x = push_lsb_bit( 13, 1 );
    printf( "push_lsb_bit( 13, 1 ) is %d\n", x );

    printf( "in binary:\n" );
    print_b32( x );


    // push_lsb_bit( 2, 1 ) is 5
    // in binary:
    // 00000000000000000000000000000101
    x = push_lsb_bit( 2, 1 );
    printf( "push_lsb_bit( 2, 1 ) is %d\n", x );

    printf( "in binary:\n" );
    print_b32( x );


    // push_lsb_bit( 1400, 1 ) is 2801
    // in binary:
    // 00000000000000000000101011110001
    x = push_lsb_bit( 1400, 1 );
    printf( "push_lsb_bit( 1400, 1 ) is %d\n", x );

    printf( "in binary:\n" );
    print_b32( x );

#if 1
    /*********** CHECKPOINT 2 ***********/
    uint32_t val = isolate_bits( 123, 5, 1 );
    printf( "val is %d\n", val );

    val = isolate_bits( 1234, 5, 1 );
    printf( "val is %d\n", val );

    val = isolate_bits( 65535, 8, 3 );
    printf( "val is %d\n", val );

    val = isolate_bits( 2147483647, 30, 20 );
    printf( "val is %d\n", val );
#endif
    

#if 1
    /*********** CHECKPOINT 3 ***********/
    uint32_t inst[] =
    {
        45459490,
        66803754,
        273938261,
        12965920,
        137929722
    };

    for ( i = 0 ; i < 5 ; i++ )
    {
        uint32_t funct_code = decode_inst( inst[i] );
        printf( "Resulting funct code is %d\n", funct_code );
    }
#endif

    return EXIT_SUCCESS;
}
