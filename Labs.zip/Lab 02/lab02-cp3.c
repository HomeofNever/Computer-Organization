#include <stdio.h>
#include <stdlib.h>

long* stored_values;

long calc_fib_recursion(long n)
{
  if (n < 2) 
    return n;
  else
    return calc_fib_recursion(n-1) + calc_fib_recursion(n-2);
}

long calc_fib_memoization(long n)
{
  long n1;
  long n2;
  if (n < 2)
    return n;
  else {
    // get first value - 
    // check if already computed - if not, compute recursively then store
    if (stored_values[n-1] >= 0) {
      n1 = stored_values[n-1];
    } else {
      n1 = calc_fib_memoization(n-1);
      stored_values[n-1] = n1;
    }

    // get second value using same approach
    if (stored_values[n-2] >= 0) {
      n2 = stored_values[n-2];
    } else {
      n2 = calc_fib_memoization(n-2);
      stored_values[n-2] = n2;
    }

    return n1 + n2;
  }
}


int main(int argc, char* argv[])
{
  long inputs[10];
  int i;
  long int max_val = 0;
  if (argc > 11) {
    fprintf(stderr, "Too many inputs, enter 10 or less\n");
    return EXIT_FAILURE;
  } else {   
    for (i = 0; i < argc-1; ++i) {
      inputs[i] = (long)atoi(argv[i+1]);
      if (inputs[i] > max_val)
        max_val = inputs[i];
    }
    // Remember: the first argument in argv[] is the executable name
  }
/*
  // naive approach
  for (i = 0; i < argc-1; ++i) {
    printf("fib(%li) is %li\n", inputs[i], calc_fib_recursion(inputs[i]));
  }
*/
  // with memoization
  // first initialize global array with sentinel values
  stored_values = (long*)malloc((max_val+1)*sizeof(long));
  for (i = 0; i <= max_val; ++i) {
    stored_values[i] = -1;
  }

  for (i = 0; i < argc-1; ++i) {
    printf("fib(%li) is %li\n", inputs[i], calc_fib_memoization(inputs[i]));
  }

  return EXIT_SUCCESS;
}

/*

Using recursion:
 time ./a.out 10 15 20 25 30 35 40 45
fib(10) is 55
fib(15) is 610
fib(20) is 6765
fib(25) is 75025
fib(30) is 832040
fib(35) is 9227465
fib(40) is 102334155
fib(45) is 1134903170

real  0m10.132s
user  0m10.108s
sys 0m0.008s


Using memoization
time ./a.out 10 15 20 25 30 35 40 45
fib(10) is 55
fib(15) is 610
fib(20) is 6765
fib(25) is 75025
fib(30) is 832040
fib(35) is 9227465
fib(40) is 102334155
fib(45) is 1134903170

real  0m0.001s
user  0m0.000s
sys 0m0.000s

*/
