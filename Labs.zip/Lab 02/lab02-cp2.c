#include <stdio.h>
#include <stdlib.h>

unsigned int gcd(unsigned int a, unsigned int b)
{
  if (b == 0)
    return a;
  else
    return gcd(b, a % b);
}

int main()
{
  unsigned int n1;
  unsigned int n2;
  printf("Enter the first integer for GCD: ");
  scanf("%u", &n1);
  printf("Enter the second integer for GCD: ");
  scanf("%u", &n2);

  printf("The GCD of %u and %u is %u\n", n1, n2, gcd(n1, n2));

  return EXIT_SUCCESS;
}

