#!/bin/bash

echo cat
echo meow
echo dog
echo woof
./scanf-examples < wisdom.txt


