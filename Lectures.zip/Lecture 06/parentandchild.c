#include <unistd.h>    /* exec, getcwd */
#include <stdio.h>     /* printf */
#include <sys/types.h> /* need for wait */
#include <sys/wait.h>  /* wait() */
#include <stdlib.h> /* EXIT_SUCCESS */

void child(void) {
  int pid = getpid();
  char input[128];

  fgets(input, 128, stdin);
  FILE* file = fopen("out.txt", "w");
  fputs(input, file);
  fclose(file);

  printf("Child (%d) done writing\n", pid);
  
}

void parent(void) {
  int pid = getpid();
  int stat;
  char input[128];

  printf("Parent process PID is %d\n", pid);
  printf("Parent waiting for child\n");
  wait(&stat);
  printf("Child is done. Parent now transporting to the surface\n");
  FILE* file = fopen("out.txt", "r");
  fgets(input, 128, file);
  printf("The following was read from the file created by a child process:\n%s", input);
  fclose(file);
}

int main(void) {
  printf("In main - starting things with a fork()\n");
  if (fork()) {
    parent();
  } else {
    child();
  }
  printf("Done in main()\n");

  return EXIT_SUCCESS;
}