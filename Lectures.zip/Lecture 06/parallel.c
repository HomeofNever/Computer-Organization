#include <unistd.h>    /* exec, getcwd */
#include <stdio.h>     /* printf */
#include <stdlib.h>    /* malloc */
#include <sys/types.h> /* need for wait */
#include <sys/wait.h>  /* wait() */
#include <sys/mman.h>  /* mmap */
#include <string.h>    /* memcpy */
#include <sys/time.h>  /* gettimeofday */
#include <stdlib.h> /* EXIT_SUCCESS */

/*
This code will calculate the dot product between two vectors. Parallelism
is achieved by using a master process to fork and create some number of 
child workers to do the calculation. We need to use mmap() to create a shared
memory segment to communicate intermediate results.

Note: There are much better/more lightweight ways to write parallel code. This
just uses fork() and wait() as an example. See 'man pthreads' or 'openmp.org' 
for more commonly used methods. We'll discuss these later in the course.
*/

double timer() 
{
  struct timeval tp;
  gettimeofday(&tp, NULL);
  return ((double) (tp.tv_sec) + 1e-6 * tp.tv_usec);
}

int main(void) {
  int N = 256*1024*1024;
  long* arr1 = (long*)malloc(N*sizeof(long));
  long* arr2 = (long*)malloc(N*sizeof(long));
  int start_index;
  int end_index;
  int child_id;
  int stat;
  int is_child = 0;
  int num_children = 4; // 4 thread contexts
  //long* sums = (long*)malloc(num_children*sizeof(long));
  void* shared_memory = mmap(NULL, num_children*sizeof(long), 
    PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_SHARED, 0, 0);
  long* shared_sums = (long*)shared_memory;
  long sum = 0;
  double elt;

  for (int i = 0; i < N; ++i) {
    arr1[i] = (unsigned)rand() % 10;
    arr2[i] = (unsigned)rand() % 10;
  }

  elt = timer(); // Time how long calculating the dot product takes

  for (int i = 0; i < num_children; ++i) {
    switch(fork()) { 
      case 0: // child
        child_id = i;
        is_child = 1;
        i = num_children;
        break;
      case -1: // error
        perror("fork");
        exit(-1);
      default: 
        break; // parent 
    }
  }

  if (is_child) {
    start_index = (N / num_children) * child_id;
    end_index = (N / num_children) * (child_id + 1);
    if (child_id == num_children-1)
      end_index = N;

    for (int i = start_index; i < end_index; ++i) {
//      arr1[i] *= 2;
//      arr2[i] *= 2;
      sum += (long)arr1[i]*2*arr2[i]*2;
    }
    if (is_child) {
      printf("child_sum: %li (%d)\n", sum, child_id);
      shared_sums[child_id] = sum;
      exit(0);
    }
  } else {
    for (int i = 0; i < num_children; ++i) {
      wait(&stat);
    }
  }

  for (int i = 0; i < num_children; ++i)
    sum += shared_sums[i];
  printf("Total sum: %li\n", sum);

  // All done
  printf("Elapsed time: %lf\n", timer() - elt);

  return EXIT_SUCCESS;
}

