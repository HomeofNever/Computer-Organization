#include <stdio.h>   /* printf */
#include <stdlib.h> /* EXIT_SUCCESS */
#include <math.h> /* log, sin */
#include <unistd.h> /* getpid */

#define PROGRESS 10

int main(int argc, char* argv[]) {

  long int i, count;
  double j = 0.0;

  printf("Enter the # of iterations: ");
  scanf("%ld", &count);
  printf("Process %d is starting for %ld iterations\n", getpid(), count);
  for (i = 0; i < count; ++i) {
  	j = sin(log(i + 1));
  	if (argc > 1 && i % (count / PROGRESS) == 0) printf("Process %d reached %lu\n", getpid(), i);
  }

  printf("Process %d is done\n", getpid());

  return EXIT_SUCCESS;
}