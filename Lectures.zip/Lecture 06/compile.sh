bin=$(echo "$1" | cut -f 1 -d '.')
gcc -Wall "$1" -o "$bin"
./"$bin"
