/* file-read.c */

#include <stdio.h>
#include <stdlib.h>

int main()
{
  int rc;  /* return code */
  int i, j, k;
  double gpa;

  /* TO DO: use non-existent file "blah.txt" here instead to see */
  /*        the perror() function display an error message...    */
  FILE * file = fopen( "xyz.txt", "r" );

  if ( file == NULL )
  {
    perror( "fopen() failed" );
    return EXIT_FAILURE;
  }

  rc = fscanf( file, "%d %d %d %lf\n", &i, &j, &k, &gpa );
  printf( "fscanf() read %d values from the file.\n", rc );
  printf( "i = %d, j = %d, k = %d, gpa = %lf\n", i, j, k, gpa);

  /* TO DO: rewrite the above using fgets() and sscanf() */

  /* fread() example */
  {
    int i;
    double arr[10];
    rc = fread( arr, sizeof( double ), 10, file );
    printf( "fread() read %d double values from the file.\n", rc );
    printf( "fread() read %lu bytes from the file.\n", rc * sizeof( double ) );

    for ( i = 0 ; i < 10 ; i++ )
    {
      printf( "sqrt( %d ) is %lf\n", i, arr[i] );
    }
  }

  fclose( file );

  return EXIT_SUCCESS;
}
