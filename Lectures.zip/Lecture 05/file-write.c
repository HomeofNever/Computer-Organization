/* file-write.c */

/* bash$ cat xyz.txt */

/* bash$ hexdump -C xyz.txt */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
  int rc;  /* return code */
  int i = 10, j = 12, k = 15;
  double gpa = 3.97;

  FILE * file = fopen( "xyz.txt", "w" );   /* man fopen */

  if ( file == NULL )
  {
    /* fprintf( stderr, "fopen() failed\n" ); */
    perror( "fopen() failed" );   /* use this if errno is set (see man page) */
    return EXIT_FAILURE;
  }

  rc = fprintf( file, "%04d %04d %04d %10.2lf\n", i, j, k, gpa );
  printf( "fprintf() wrote %d bytes to the file.\n", rc );
  printf( "i = %d, j = %d, k = %d, gpa = %lf\n", i, j, k, gpa);

  /* using fwrite() */
  {
    int i;
    double arr[10];
    for ( i = 0 ; i < 10 ; i++ ) arr[i] = sqrt( i );
    rc = fwrite( arr, sizeof( double ), 10, file );
    printf( "fwrite() wrote %lu bytes to the file.\n", rc * sizeof( double ) );
  }


  fclose( file );

  return EXIT_SUCCESS;
}
