#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main()
{

  printf("Today is %s at %s\n", __DATE__, __TIME__);

  return EXIT_SUCCESS;
}
