#include <stdio.h>
#include <stdlib.h>
#include <math.h>

 /* try running this with scanf() uncommented below and
     enter names that exceed 20 bytes.....
      .....when does it crash?  and why? */

int main()
{
  float x;         /*       +-----------------+ */
  char name[20];   /* name=>| | | | | | ... | | */
  char name2[20];  /* name=>| | | | | | ... | | */
                   /*       +-----------------+ */

                   /*  name[5]  is equivalent to  *(name+5)   */

  printf("Enter your name (first) (last): " );
  scanf( "%s %s", name, name2 );
  printf( "hello %s %s\n", name, name2);

  printf( "Enter a number: ");
  scanf("%f", &x);
  printf( "The square root of %f is %f\n", x, sqrt( x ) );

  printf( "Enter your name: " );

#if 0
  scanf( "%s", name );             /* name is char* as its data type */
#endif

  getchar();   //read/consume the newline '\n' from the previous input 

  if ( fgets( name, 20, stdin ) == NULL )
  {
    fprintf( stderr, "ERROR: fgets() failed\n" );
    return EXIT_FAILURE;
  }

  printf( "Hi, %s.\n", name );

  return EXIT_SUCCESS;
}
