#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

void print_output(int n) 
{ 
  printf("Hello World: %d\n", n); 
}

int main()
{
  void (*function_ptr)(int) = &print_output;
  printf("%p %p\n", function_ptr, &print_output);
  (function_ptr)(5);

  return EXIT_SUCCESS;
}
