#include<string.h>
#include<stdlib.h>
#include<stdio.h>

int main(void) {
	char* a = "Engineers";
	FILE* fp1 = fopen("file1", "w");  
	FILE* fp2 = fopen("file2", "w");
	fprintf(fp1, "%s\n", a);
	fwrite(a, 1, strlen(a), fp2);
	return EXIT_SUCCESS;
}