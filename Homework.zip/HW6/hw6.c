/* hw6.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LRU 1
#define BELADY 2

#define MAX_ACCESSES 1024

int main( int argc, char * argv[] )
{
  if ( argc != 4 )
  {
    fprintf( stderr, "ERROR: Invalid arguments\n" );
    fprintf( stderr, "USAGE: %s <cache-associativity> <algorithm> <input-file>\n", argv[0] );
    return EXIT_FAILURE;
  }

  int associativity = atoi( argv[1] );  /* 1, 2, or 4 */

  if ( associativity != 1 && associativity != 2 && associativity != 4 )
  {
    fprintf( stderr, "ERROR: Invalid associativity\n" );
    fprintf( stderr, "USAGE: %s <cache-associativity> <algorithm> <input-file>\n", argv[0] );
    return EXIT_FAILURE;
  }

  int algorithm = 0;

  if ( strcmp( argv[2], "LRU" ) == 0 ) algorithm = LRU;
  else if ( strcmp( argv[2], "Belady" ) == 0 ) algorithm = BELADY;
  else
  {
    fprintf( stderr, "ERROR: Invalid algorithm\n" );
    fprintf( stderr, "USAGE: %s <cache-associativity> <algorithm> <input-file>\n", argv[0] );
    return EXIT_FAILURE;
  }

  int i = 0, j = 0, k = 0;
  char buffer[128];
  int accesses[MAX_ACCESSES];
  memset( accesses, 0, MAX_ACCESSES * sizeof( int ) );

  FILE * file = fopen( argv[3], "r" );
  while ( fgets( buffer, 128, file ) != NULL ) accesses[i++] = atoi( buffer );
  fclose( file );

#ifdef DEBUG_MODE
  printf( "i: %d\n", i );
  for ( j = 0 ; j < i ; j++ ) printf( "[%d]: %d\n", j, accesses[j] );
#endif

  printf( "Cache size: 256\nCache associativity: %d\n", associativity );

  int sets = 256 / associativity;
  printf( "Cache sets: %d\n", sets );
  printf( "Cache algorithm: %s\n", algorithm == LRU ? "LRU" : "Belady" );


  /* dynamically allocate memory for cache structure */
  int ** cache = calloc( sets, sizeof( int * ) );

  if ( cache == NULL )
  {
    perror( "calloc() failed" );
    return EXIT_FAILURE;
  }

  for ( j = 0 ; j < sets ; j++ )
  {
    cache[j] = calloc( associativity, sizeof( int ) );

    if ( cache[j] == NULL )
    {
      perror( "calloc() failed" );
      return EXIT_FAILURE;
    }
  }


  /* simulate the cache */
  int hit = 0, hits = 0, misses = 0;

  for ( j = 0 ; j < i ; j++ )
  {
    int set = accesses[j] % sets;

#ifdef DEBUG_MODE
    printf( "%d ==> %d\n", accesses[j], set );
#endif

    hit = 0;

    for ( k = 0 ; k < associativity && cache[set][k] != 0 ; k++ )
    {
      if ( cache[set][k] == accesses[j] )
      {
        int q;
#ifdef DEBUG_MODE
        printf( "cache set before hit: [ " );
        for ( q = 0 ; q < associativity ; q++ ) printf( "%d ", cache[set][q] );
        printf( "]; after [ " );
#endif
        hit = 1;
        hits++;

        /* move current hit into the "oldest" slot */
        q = k;
        while ( q < associativity - 1 && cache[set][q+1] != 0 )
        {
          cache[set][q] = cache[set][q+1];
          q++;
        }
        cache[set][q] = accesses[j];

#ifdef DEBUG_MODE
        for ( q = 0 ; q < associativity ; q++ ) printf( "%d ", cache[set][q] );
        printf( "]\n" );
#endif
        break;
      }
    }

    if ( hit == 0 )
    {
      misses++;

      if ( k < associativity )
      {
        cache[set][k] = accesses[j];
      }
      else if ( associativity == 1 )
      {
#ifdef DEBUG_MODE
        printf( "replacing %d with %d at set %d\n", cache[set][0], accesses[j], set );
#endif

        cache[set][0] = accesses[j];
      }
      else
      {
#ifdef DEBUG_MODE
        printf( "cache full at set %d; before: [ ", set );
        for ( k = 0 ; k < associativity ; k++ ) printf( "%d ", cache[set][k] );
        printf( "]; after [ " );
#endif
        if ( algorithm == LRU )
        {
          for ( k = 0 ; k < associativity - 1 ; k++ )
          {
            cache[set][k] = cache[set][k+1];
          }

          cache[set][k] = accesses[j];
        }
        else if ( algorithm == BELADY )
        {
          int v = 0, z = 0, max = 0;

          for ( k = 0 ; k < associativity ; k++ )
          {
            for ( z = j + 1 ; z < i ; z++ )
            {
              if ( accesses[z] == cache[set][k] )
              {
                if ( z > max ) { max = z; v = k; }
                break;
              }
            }

            if ( z == i ) /* not found */
            {
              if ( z > max || ( z == max && cache[set][k] < cache[set][v] ) )
              {
                max = z;
                v = k;
              }
            }
          }

          cache[set][v] = accesses[j];
        }

#ifdef DEBUG_MODE
        for ( k = 0 ; k < associativity ; k++ ) printf( "%d ", cache[set][k] );
        printf( "]\n" );
#endif
      }
    }

    printf( "%d (%s)\n", accesses[j], hit == 1 ? "hit" : "miss" );
  }

  printf( "Cache accesses: %d\n", i );
  printf( "Cache hits: %d\n", hits );
  printf( "Cache misses: %d\n", misses );
  printf( "Overall hit rate: %f\n", ( hits + 0.0 ) / i );


  /* free dynamically allocated memory */
  for ( j = 0 ; j < sets ; j++ ) free( cache[j] );
  free( cache );


  return EXIT_SUCCESS;
}
