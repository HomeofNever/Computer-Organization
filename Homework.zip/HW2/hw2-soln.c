/* hw2.c */
/* NAME: Solution McSolutionface */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>

#define GENERATE_MIPS 0
#define RAND_RANGE 100

int width( int x )
{
  int w = 1;
  while ( x /= 10 ) w++;
  return w;
}

int main()
{
  char line[256];

  printf( "Please enter a valid C assignment statement:\n" );

  if ( fgets( line, 256, stdin ) == NULL )
  {
    fprintf( stderr, "fgets() failed" );
    return EXIT_FAILURE;
  }

  char variables[10];
  char instruction[128];
  char output[1024]; output[0] = '\0';
  int i = 0;
  int t = 0;
  int s = 1;
  int q, imm;
  char operator;
  char operandtype; /* 'I'mmediate or 'R'egister */
  int firsttime = 1;
  char * fo, * so;

#if GENERATE_MIPS
  srand(time(NULL));
  char code[10240];
  sprintf(code, "# %s", line);
  sprintf(code + strlen( code ), "      .text\n      .globl main\nmain: ");
#endif

  printf( "The MIPS pseudocode is:\n" );

  /* determine $s0 */
  sscanf( line, "%c =", &variables[0] );
  i += 3;
  while ( line[i] == ' ' ) i++;

  /* determine first operand */
  if ( isalpha( line[i] ) )
  {
    sscanf( line + i, "%c", &variables[s++] );
    if ( variables[0] == variables[1] ) s--;
    while ( line[++i] == ' ' );
    operandtype = 'R';
  }
  else if ( isdigit( line[i] ) )
  {
    sscanf( line + i, "%d", &imm );
    i += width( imm );
    while ( line[i] == ' ' ) i++;
    operandtype = 'I';
  }
  else { fprintf( stderr, "Parsing error...\n" ); return EXIT_FAILURE; }

  while ( line[i] != ';' && line[i] != '\n' && line[i] != '\0' )
  {
    /* proceed through the whitespace */
    while ( line[i] == ' ' || line[i] == '\t' ) i++;

    /* determine the operator */
    sscanf( line + i, "%c", &operator );
    while ( line[++i] == ' ' );

    /* print the instruction operator */
    if ( operator == '+' ) strcpy( instruction, "add  " );
    else if ( operator == '-' ) strcpy( instruction, "sub  " );
    else { fprintf( stderr, "Parsing error...\n" ); return EXIT_FAILURE; }

    /* print the first (target) operand */
    fo = instruction + strlen( instruction );
    sprintf( instruction + strlen( instruction ), "$t%d,", t++ );
    if ( t > 9 ) t = 0;

    /* print the second operand */
    if ( firsttime )
    {
      firsttime = 0;
      if ( operandtype == 'R' ) 
        sprintf( instruction + strlen( instruction ), "$s%d,", s - 1 );
      else if ( operandtype == 'I' )
      {
        sprintf( output + strlen( output ), "addi $t%d,$zero,%d\n", ( t + 9 ) % 10, imm);
        so = instruction + strlen( instruction );
        sprintf(instruction + strlen( instruction ), "$t%d,", t++);
        strncpy( fo, so, 4);
        sprintf( so, "$t%d,", ( t + 8 ) % 10 );
      }
    }
    else
    {
      sprintf( instruction + strlen( instruction ), "$t%d,", ( t + 8 ) % 10 );
    }

    if ( isalpha( line[i] ) )
    {
      sscanf( line + i, "%c", &variables[s] );

      /* check for repeated variables */
      for ( q = 0 ; q < s ; q++ )
      {
        if ( variables[q] == variables[s] ) break;
      }
      if ( q < s ) q++; else { s++; q++; }

      while ( line[++i] == ' ' );
      operandtype = 'R';
    }
    else if ( isdigit( line[i] ) )
    {
      sscanf( line + i, "%d", &imm );
      i += width( imm );
      while ( line[i] == ' ' ) i++;
      operandtype = 'I';
    }
    else { fprintf( stderr, "Parsing error...\n"); return EXIT_FAILURE; }

    /* print the third operand */
    if ( operandtype == 'R' ) 
      sprintf( instruction + strlen( instruction ), "$s%d\n", q - 1 );
    else if ( operandtype == 'I' )
    {
      if ( operator == '-' ) imm = -imm;
      strncpy( instruction, "addi ", 5 );
      sprintf( instruction + strlen( instruction ), "%d\n", imm );
    }
    
    /* replace first operand if we're at the end of the statement */
    if ( line[i] == ';' ) 
      strncpy( fo, "$s0", 3 );
    
    strcat(output, instruction);
  }

  /* if the assignment statement isn't semicolon-terminated */
  if ( line[i] != ';' )
    { fprintf( stderr, "Parsing error...\n"); return EXIT_FAILURE; }
  else
    printf( "%s", output );

#if GENERATE_MIPS
  char values[10];
  char expression[256] = "";
  char command[256];
  int e, eval;
  FILE * fp;

  for ( q = 0 ; q < s ; q++ )
  {
    if ( q > 0 ) sprintf(code + strlen( code ), "      ");
    values[q] = (unsigned int)rand() % RAND_RANGE;
    sprintf(code + strlen( code ), "li    $s%d, %d     # %c = %d\n", q, values[q], variables[q], values[q]);
  }
  for ( q = 0; q < strlen( output ); q++ )
  {
    if ( q == 0 ) sprintf( code + strlen( code ), "\n      ");
    i = strlen ( code ) - 1;
    code[++i] = output[q];
    code[++i] = '\0';
    if ( output[q] == '\n' ) sprintf( code + strlen( code ), "      ");
  }
  sprintf(code + strlen( code ), "\n      li $v0, 1\n      move $a0, $s0\n      syscall        # print_int ");
  q = 0;
  while ( line[q] != '=' ) q++;
  q++;
  while ( q < strlen( line ) )
  {
        if (isalpha(line[q])) {
          for (i = 0; i < s; i++)
            if (variables[i] == line[q]) break;
          sprintf(expression + strlen( expression ), "%d", values[i]);
        }
        else if ( line[q] != ';' && line[q] != '\n' ) {
          e = strlen( expression ) - 1;
          expression[++e] = line[q];
          expression[++e] = '\0';
        }
        q++;
  }
  strcpy( command, "echo $(( " );
  strcat( command, expression );
  strcat( command, " ))" );
  if ( ( fp = popen( command, "r" ) ) == NULL ) {
      printf( "Error opening pipe!\n" );
      return EXIT_FAILURE;
  }
  fgets( command, 256, fp );
  if( pclose( fp ) )  {
      printf( "Command not found or exited with error status\n" );
      return EXIT_FAILURE;
  }
  sscanf(command, "%d", &eval);
  sprintf(code + strlen( code ), "(%c = %s = %d)\n      jr $ra", variables[0], expression, eval);
  printf( "Actual MIPS code:\n%s\n", code );
#endif

  return EXIT_SUCCESS;
}
