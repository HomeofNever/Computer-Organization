/* hw2.c */
/* NAME: <your-name-here> */

#include <stdio.h>
#include <stdlib.h>

int main( int argc, char * argv[] )
{
  char line[256];

  printf("Please enter a valid C assignment statement:\n");
  if (fgets(line, 256, stdin) == NULL)
  {
    fprintf(stderr, "fgets() failed");
    return EXIT_FAILURE;
  }

  printf("The MIPS pseudocode is:\n");

  // Do your magic here

  // if (error occurs) 
  //   { fprintf( stderr, "Parsing error...\n" ); return EXIT_FAILURE; }


  return EXIT_SUCCESS;
}

