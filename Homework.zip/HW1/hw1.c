/* hw1.c */
/* NAME: <your-name-here> */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main( int argc, char * argv[] )
{
  /* Ensure we have the correct number of command-line arguments */
  if ( argc != 5 )
  {
    fprintf( stderr, "ERROR: Invalid inputs!\n" );
    return EXIT_FAILURE;
  }


  return EXIT_SUCCESS;
}

