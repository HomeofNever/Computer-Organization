/*****************************************************************************/
/* Assignment 1: 2-D/ Matrix Multiplication **********************************/
/* Name: YOUR NAME GOES HERE *************************************************/
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>


int** matrix_alloc(int rows, int cols)
{
  int** temp = calloc(rows, sizeof(int*));
  for (int i = 0; i < rows; i++) {
    temp[i] = calloc(cols, sizeof(int));
  }

  return temp;
}

void matrix_free(int** matrix, int rows)
{
  for (int i = 0; i < rows; i++) {
    free(matrix[i]);
  }
  free(matrix);
}

void matrix_read(char* name, int** matrix, int rows, int cols)
{
  printf("Please enter the values for the %s matrix (%dx%d):\n", 
    name, rows, cols);

  for (int i = 0; i < rows; i++) {
    for (int j = 0; j < cols; j++) {
      scanf("%d", &matrix[i][j]);
    }
  }
}

void matrix_print(int** matrix, int rows, int cols)
{
  int* widths = calloc(cols, sizeof(int));
  for (int i = 0; i < cols; ++i) {
    int max = 0;
    for (int j = 0; j < rows; ++j) {
      if (matrix[j][i] > max) 
        max = matrix[j][i];
    }

    widths[i] = 1;
    while ((max /= 10) > 0) 
      ++widths[i];
  }

  for (int i = 0; i < rows; ++i) {
    printf("[%*d", widths[0], matrix[i][0]);
    for (int j = 1; j < cols; j++) {
      printf(" %*d", widths[j], matrix[i][j]);
    }
    printf("]\n");
  }
  free(widths);
}

void matrix_mult(int** matrix1, int m1_rows, int m1_cols,
                 int** matrix2, int m2_rows, int m2_cols,
                 int** results)
{
  for (int i = 0; i < m1_rows; ++i) {
    for (int j = 0; j < m2_cols; ++j) {
      for (int k = 0; k < m1_cols; ++k) {
          results[i][j] += matrix1[i][k] * matrix2[k][j];
      }
    }
  }
}

int main(int argc, char* argv[])
{
  if (argc != 5) {
    fprintf(stderr, "ERROR: Invalid inputs!\n");
    return EXIT_FAILURE;
  }

  int** matrix1 = NULL;
  int** matrix2 = NULL;
  int** results = NULL;

  int m1_rows, m1_cols, m2_rows, m2_cols;
  m1_rows = atoi(argv[1]);
  m1_cols = atoi(argv[2]);
  m2_rows = atoi(argv[3]);
  m2_cols = atoi(argv[4]);

  if (m1_cols != m2_rows) {
    fprintf(stderr, "ERROR: Invalid inputs!\n");
    return EXIT_FAILURE;
  }

  matrix1 = matrix_alloc(m1_rows, m1_cols);
  matrix2 = matrix_alloc(m2_rows, m2_cols);
  results = matrix_alloc(m1_rows, m2_cols);

  matrix_read( "first", matrix1, m1_rows, m1_cols);
  matrix_read("second", matrix2, m2_rows, m2_cols);
  printf("\n");

  matrix_mult(matrix1, m1_rows, m1_cols, 
              matrix2, m2_rows, m2_cols, 
              results);

  matrix_print(matrix1, m1_rows, m1_cols);
  printf("multiplied by\n");
  matrix_print(matrix2, m2_rows, m2_cols);
  printf("equals\n");
  matrix_print(results, m1_rows, m2_cols);

  matrix_free(matrix1, m1_rows);
  matrix_free(matrix2, m2_rows);
  matrix_free(results, m1_rows);

  return EXIT_SUCCESS;
}